﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _500626_appformovietheater
{

    class program
    {
        public static List<normal_theater> l1 = new List<normal_theater>();

        public static List<pvr_theater> l2 = new List<pvr_theater>();

        static void Main(string[] args)
        {

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("-----------------------------------------------");
            Console.BackgroundColor = ConsoleColor.Cyan;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("<<<<<<< WELCOME TO MOVIE THEATER APPLICATION >>>>>>>");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("-----------------------------------------------");
            string Confirm;
            do
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("1. NormalTheater \n2. PVR Theater");
                Console.ForegroundColor = ConsoleColor.White;

                int choice = Convert.ToInt32(Console.ReadLine());


                switch (choice)
                {
                    case 1:
                        displayMenu();
                        normal_theater NR = new normal_theater();
                        normal_theater NR1 = new normal_theater("abc", 100, "Bangalore", "Basvangugi", 500, 100);
                        Options(NR);
                        break;

                    case 2:
                        displayMenu();
                        pvr_theater PT = new pvr_theater();
                        pvr_theater PT1 = new pvr_theater("def", 101, "Mysore", "Kuvempunagar", 300, 100);
                        Options(PT);
                        break;

                    default:
                        Console.WriteLine("Please choose a valid option");
                        break;
                }
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Enter 'y' to continue");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.White;
                Confirm = Console.ReadLine().ToUpper();
            } while (Confirm == "Y");


        }
        public static void displayMenu()
        {
            Console.BackgroundColor = ConsoleColor.Yellow;

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("______MENU______");
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("1.Add New Theater");
            Console.WriteLine("2.Delete Theater");
            Console.WriteLine("3.DisplayAllTheater");
            Console.WriteLine("4.Search By City");
            Console.WriteLine("5.Search by Theater Name");
            Console.WriteLine("6.Search By Licance Number");
           

        }
        public static void Options(normal_theater obj)
        {
            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    obj.Add_Newtheater();
                    break;
                case 2:
                    obj.Delete_theater();
                    break;
                case 3:
                    obj.Display_alltheater();
                    break;
                case 4:
                    obj.SearchByCity();
                    break;
                case 5:
                    obj.SearchByTheaterName();
                    break;
                case 6:
                    obj.SearchByLicenceNumber();
                    break;
               
                default:
                    Console.WriteLine("Please choose a valid option");
                    break;
            }
        }
        public static void Options(pvr_theater obj)
        {
            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    obj.Add_Newtheater();
                    break;
                case 2:
                    obj.Delete_theater();
                    break;
                case 3:
                    obj.Display_alltheater();
                    break;
                case 4:
                    obj.SearchByCity();
                    break;
                case 5:
                    obj.SearchByTheaterName();
                    break;
                case 6:
                    obj.SearchByLicenceNumber();
                    break;

                default:
                    Console.WriteLine("Please choose a valid option");
                    break;
            }
            Console.ReadLine();
        }
    }

}

        abstract class theater
    {
        public string Name;
        public int Licence_No;
        public string City_name;
        public string Address;
        public int Maxticketprice;
        public int Minticketprice;
        public void Add_Newtheater() { }
        public void Delete_theater() { }
        public void Display_alltheater() { }
        public void SearchByCity() { }
        public void SearchByTheaterName() { }
        public void SearchByLicenceNumber() { }
    }


    

   

    



