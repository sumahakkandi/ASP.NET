﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _500626_appformovietheater
{
    class pvr_theater:theater
    {

        public int Maxcapacity { get; set; }
        public int Mincapacity { get; set; }
        public int Minticketprice { get; set; }
        public int Maxticketprice { get; set; }

        int i = 1;
        
        public pvr_theater() { }//no arguments construtor
        public pvr_theater(string n, int ln, string cname, string add, int max, int min)//construtor with arguments
        {
            Name = n;
            Licence_No = ln;
            City_name = cname;
            Address = add;
            Maxticketprice = max;
            Minticketprice = min;

        }
        public void Add_Newtheater()
        {
            pvr_theater PT = new pvr_theater();
            Console.WriteLine("Enter the Theater name");
            PT.Name = Console.ReadLine();
            Console.WriteLine("Enter the City");
            PT.City_name = Console.ReadLine();
            Console.WriteLine("Enter the Theater Address");
            PT.Address = Console.ReadLine();
            Console.WriteLine("Enter the Maxticket price");
            PT.Maxticketprice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Minticket price");
            PT.Minticketprice = Convert.ToInt32(Console.ReadLine());
            PT.Licence_No = 200 + i++;
            Console.WriteLine("Enter the Maximum capacity of the theater");
            PT.Maxcapacity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Minimum capacity of the theater");
            PT.Mincapacity = Convert.ToInt32(Console.ReadLine());
            program.l2.Add(PT);
        }
        public void Delete_theater()
        {
            string tname;
            Console.WriteLine("Enter the Theater name");
            tname = Console.ReadLine();
            try
            {
                int count = 0;
                foreach (var temp in program.l2)
                {
                    count++;
                    if (temp.Name == tname)
                    {

                        program.l2.Remove(temp);
                        Console.WriteLine("theater details deleted successfully");

                        break;
                    }

                    else if (program.l2.Count == count)
                    {
                        throw new NoTheaterException("invalid theater name, please enter correct name");
                    }
                }
            }

            catch (NoTheaterException e)
            {
                Console.WriteLine(e.Message);
            }
        }

       
        public void Display_alltheater()
        {
            Console.WriteLine("list of theaters");
           
            foreach (var item in program.l2)
            {
               
                Console.WriteLine(item.ToString());

            }

        }
        public void SearchByCity()
        {
            string cname;
            Console.WriteLine("Enter the City name");
            cname = Console.ReadLine();

            int count = 0;
            foreach (var temp1 in program.l2)
            {
                count++;
                if (temp1.City_name == cname)
                {

                    Console.WriteLine("Theater found");
                    Console.WriteLine(temp1.Name);
                    Console.WriteLine(temp1.Address);
                    Console.WriteLine(temp1.City_name);

                    break;
                }

                else if (count == program.l2.Count)
                {
                    Console.WriteLine("theater not found");
                }
            }
        }

        public void SearchByTheaterName()
        {
            string tname;
            Console.WriteLine("Enter the theater name");
            tname = Console.ReadLine();

            int count = 0;
            foreach (var temp2 in program.l2)
            {
                count++;
                if (temp2.Name == tname)
                {

                    Console.WriteLine("Theater found");
                    Console.WriteLine(temp2.Name);
                    Console.WriteLine(temp2.Address);
                    Console.WriteLine(temp2.City_name);

                    break;
                }

                else if (count == program.l2.Count)
                {
                    Console.WriteLine("theater not found");
                }
            }
        }

        public void SearchByLicenceNumber()
        {
           int num;
            Console.WriteLine("Enter the theater name");
            num = Convert.ToInt32(Console.ReadLine());

            int count = 0;
            foreach (var temp2 in program.l2)
            {
                count++;
                if (temp2.Licence_No== num)
                {

                    Console.WriteLine("Theater found");
                    Console.WriteLine(temp2.Name);
                    Console.WriteLine(temp2.Address);
                    Console.WriteLine(temp2.City_name);

                    break;
                }

                else if (count == program.l2.Count)
                {
                    Console.WriteLine("theater not found");
                }
            }
        }

    }
}
