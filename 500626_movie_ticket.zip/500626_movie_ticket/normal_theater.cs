﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _500626_appformovietheater
{
    class normal_theater:theater
    {
            public int Maxcapacity { get; set; }
            public int Mincapacity { get; set; }
            public int Minticketprice { get; set; }
            public int Maxticketprice { get; set; }
            int i = 0;


            public normal_theater() { } //no argument constructor  
            public normal_theater(string n, int ln, string cname, string add, int max, int min)//constructor with arguments.
            {
                Name = n;
                Licence_No = ln;
                City_name = cname;
                Address = add;
                Maxticketprice = max;
                Minticketprice = min;

            }
            public void Add_Newtheater()
            {
                normal_theater NT = new normal_theater();
                Console.WriteLine("Enter the Theater name");
                NT.Name = Console.ReadLine();
                Console.WriteLine("Enter the City");
                NT.City_name = Console.ReadLine();
                Console.WriteLine("Enter the Theater Address");
                NT.Address = Console.ReadLine();
                Console.WriteLine("Enter the Maxticket price");
                NT.Maxticketprice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Minticket price");
                NT.Minticketprice = Convert.ToInt32(Console.ReadLine());
                NT.Licence_No = 100 + ++i;
                Console.WriteLine("Enter the Max capacity of the theater");
                NT.Maxcapacity = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Min capacity of the theater");
                NT.Mincapacity = Convert.ToInt32(Console.ReadLine());
                program.l1.Add(NT);
            }
            public void Delete_theater()
            {
                string tname;
                Console.WriteLine("Enter the Theater name");
                tname = Console.ReadLine();
                try
                {
                    int count = 0;
                    foreach (var temp in program.l1)
                    {
                        count++;
                        if (temp.Name == tname)
                        {

                            program.l1.Remove(temp);
                            Console.WriteLine("theater details deleted successfully");

                            break;
                        }

                        else if (program.l1.Count == count)
                        {
                            throw new NoTheaterException("no theater found");
                        }
                    }
                }

                catch (NoTheaterException e)
                {
                    Console.WriteLine(e.Message);
                }
            }

       
        public void Display_alltheater()
            {
                Console.WriteLine("list of theaters");
                foreach (var item in program.l1)
                {
                    Console.WriteLine(item.Name);

                }

            }
            public void SearchByCity()
            {
                string cname;
                Console.WriteLine("Enter the City name");
                cname = Console.ReadLine();

                int count = 0;
                foreach (var temp1 in program.l1)
                {
                    count++;
                    if (temp1.City_name == cname)
                    {

                        Console.WriteLine("Theater found");
                        Console.WriteLine(temp1.Name);
                        Console.WriteLine(temp1.Address);
                        Console.WriteLine(temp1.City_name);

                        break;
                    }

                    else if (count == program.l1.Count)
                    {
                        Console.WriteLine("theater not found");
                    }
                }
            }

            public void SearchByTheaterName()
            {
                string tname;
                Console.WriteLine("Enter the theater name");
                tname = Console.ReadLine();

                int count = 0;
                foreach (var temp2 in program.l1)
                {
                    count++;
                    if (temp2.Name == tname)
                    {

                        Console.WriteLine("Theater found");
                        Console.WriteLine(temp2.Name);
                        Console.WriteLine(temp2.Address);
                        Console.WriteLine(temp2.City_name);

                        break;
                    }

                    else if (count == program.l1.Count)
                    {
                        Console.WriteLine("theater not found");
                    }
                }
            }
        public void SearchByLicenceNumber()
        {
            int num;
            Console.WriteLine("Enter the theater name");
            num = Convert.ToInt32(Console.ReadLine());

            int count = 0;
            foreach (var temp2 in program.l1)
            {
                count++;
                if (temp2.Licence_No == num)
                {

                    Console.WriteLine("Theater found");
                    Console.WriteLine(temp2.Name);
                    Console.WriteLine(temp2.Address);
                    Console.WriteLine(temp2.City_name);

                    break;
                }

                else if (count == program.l1.Count)
                {
                    Console.WriteLine("theater not found");
                }
            }
        }
        
    }
}

