﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _500626_appformovietheater
{
        class NoTheaterException : Exception
        {
            public NoTheaterException(string message) : base(message) { }
        }

 }

