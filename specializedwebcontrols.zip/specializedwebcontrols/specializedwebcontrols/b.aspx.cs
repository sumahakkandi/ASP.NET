﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace specializedwebcontrols
{
    public partial class b : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            System.Collections.Specialized.NameValueCollection col = Request.Form;
            Label1.Text = col["TextBox1"];
            Label2.Text = col["TextBox2"];
            //Page pre = Page.PreviousPage;
            //if (pre != null)
            //{
            //Label1.Text = ((TextBox)pre.FindControl("TextBox1")).Text;
            //Label2.Text = ((TextBox)pre.FindControl("TextBox2")).Text;

            //}
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}