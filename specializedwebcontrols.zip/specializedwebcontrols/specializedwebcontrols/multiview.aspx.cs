﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace specializedwebcontrols
{
    public partial class multiview : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (MultiView1.ActiveViewIndex == 0)
            {
                MultiView1.SetActiveView(View2);
            }
            else if (MultiView1.ActiveViewIndex == 1)
            {
                MultiView1.SetActiveView(View3);
                if (String.IsNullOrEmpty(TextBox1.Text))
                {
                    Literal1.Text = "You did not enter your name. ";
                }
                else
                {
                    Literal1.Text = "Hi, " + TextBox1.Text + ". ";
                }
            }
            else if (MultiView1.ActiveViewIndex == 2)
            {
                MultiView1.SetActiveView(View1);
            }
        }
    }
    }
