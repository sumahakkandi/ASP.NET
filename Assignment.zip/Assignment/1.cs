﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace callback
{

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the number to be reverse");
            int n = int.Parse(Console.ReadLine());
            int rem;
            int rev = 0;
            while (n != 0)
            {
                rem = n % 10;
                rev = rev * 10 + rem;
                n = n / 10;
            }
            Console.WriteLine("reverse of the number is" + rev);
            Console.ReadLine();

        }
    }
}
