﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise14
{
    public class BankAccount
    {
        public int accountnum;
        public string owner;
        public string typeofaccount;
        public int balance;

        public void details()
        {
            Console.WriteLine("account number");
            int accountnum = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("owner");
            string owner = Console.ReadLine();
            Console.WriteLine("typeofaccount");
            string typeofaccount = Console.ReadLine();
            Console.WriteLine("balance");
             balance = Convert.ToInt32(Console.ReadLine());
        }


        public void Withdraw(int amount)
        {
          
            balance =balance-  amount;
            display();
            Console.WriteLine($"balance={balance}");
            Console.ReadLine();
        }

        public void Deposit(int amount)
        {
            balance = balance+ amount;
            Console.WriteLine($"balance={balance}");
            display();
            Console.ReadLine();
        }
          public void display()
           {
              Console.WriteLine(balance);
               Console.WriteLine(owner);
           }
    }
    class bankdetails
    {
        static void Main(string[] args)
        {
            BankAccount ba = new BankAccount();
            ba.details();
            int choice = Convert.ToInt32(Console.ReadLine());
            switch(choice)
            {
                case 1:
                    ba.Deposit(100);
                    break;
                case 2:  ba.Withdraw(100);
                    break;
            }
                
            

        }
    }
}

