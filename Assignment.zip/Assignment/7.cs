﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mean
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the no. of array elemnts");
           int n= int.Parse(Console.ReadLine());
            Console.WriteLine("enter" + n + "numbers");

            int[] a = new int[n];
            for (int i = 0; i < a.Length; i++)
            {
                a[i] = Convert.ToInt32(Console.ReadLine());
            }

             for (int j = 0; j < a.Length; j++)
            {
                Console.WriteLine("Element[{0}] = {1}", j, a[j]);
            }
            Console.ReadLine();
            Console.WriteLine("Mean of the numbers is");
            findmean(a,a.Length);
            findmedian(a, a.Length);
            findvarience(a, a.Length);
           
            }

     

        private static void findvarience(int[] a, int length)
        {
            double varience;
            double sd;
            int sum = 0;
            for (int i = 0; i < length; ++i)
            {
                sum += (a[i]*a[i]);
            }
            varience = (double)sum / length;
            sd = Math.Sqrt(varience);
            Console.WriteLine("var=" + varience);
            Console.WriteLine("sd=" + sd);
            Console.ReadLine();

        }

        private static void findmedian(int[] a, int length)
        {
           int mid = length / 2;
            if(mid%2==0)
            {
                Console.WriteLine("Median" + "{0 }", ((a[mid] + a[mid - 1]) / 2));
                

            }
            else
            {
                Console.WriteLine("Median" + "{0 }", (a[mid]));
             }

            Console.ReadLine();

        }

        private static void findmean(int[] a, int length)
        {
            double avg;
            int sum = 0;
            for (int i = 0; i < length; ++i)
            {
                sum += a[i];
            }
            avg = (double)sum / length;
            Console.WriteLine("mean=" + avg);
            Console.ReadLine();
                
        }
    }
}
