﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace isprime
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a number to check whether prime or not");
            int num = Convert.ToInt32(Console.ReadLine());
            bool result = is_prime(num);
            Console.WriteLine(result);
            Console.ReadLine();

        }
        private static bool is_prime(int num)
        {
            int i = 2;
            while (i <= num / 2)
            {
                if (num % i == 0)
                {
                    return false;

                }
                i++;

            }
            return true;
        }
    }
}
