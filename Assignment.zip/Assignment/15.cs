﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalArea
{
    class shape
    {
        static void Main(string[] args)
        {
            DisplayMenu();
            int ch = Convert.ToInt32(Console.ReadLine());
            switch (ch)
            {
                case 1:
                    Rectangle r1 = new Rectangle();
                    r1.SetValues();
                    r1.area();
                    break;
                case 2:
                    Triangle t1 = new Triangle();
                    t1.SetValues();
                    t1.area();
                    break;

            }
        }

        static void DisplayMenu()
        {
            Console.WriteLine("Choose the geometical shape");
            string[] menu ={
                "1.Rectangle",
                "2.Traingle"
            };
            for (int i = 0; i < menu.Length; i++)
            {
                Console.WriteLine(menu[i]);
            }
        }
    }

    class Shape
    {
        public double length;
        public double breadth;
        public void SetValues()
        {
            Console.WriteLine("Enter the length value");
            length = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the breadth value");
            breadth = Convert.ToDouble(Console.ReadLine());

        }
        public virtual void area()
        {
            Console.WriteLine("The area is computed");

        }
    }

    class Rectangle : Shape
    {
        double a_of_rect;
        public override void area()
        {
            a_of_rect = length * breadth;
            Console.WriteLine("The area of the rectangle is " + a_of_rect);
            Console.ReadLine();
        }
    }
    class Triangle : Shape
    {
        double a_of_tri;
        public override void area()
        {
            a_of_tri = (0.5) * length * breadth;
            Console.WriteLine("The area of the triangle is " + a_of_tri);
            Console.ReadLine();
        }
    }

}
