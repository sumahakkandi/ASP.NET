﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace converter
{
    class Program
    {
        static void Main(string[] args)
        {
            int dollar;

            Console.WriteLine("Enter amount in us$");
            int.TryParse(Console.ReadLine(), out dollar);
            if (dollar != 0)
            {
                double rupees = dollar * 65.48;
                double pound = dollar * 0.81;

                Console.WriteLine($"{dollar}$ in indian rupees= {rupees} ");
                Console.WriteLine($"{dollar}$ in indian rupees= {pound} ");
            }

            Console.ReadLine();
        }
    }
    }