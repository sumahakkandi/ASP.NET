﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace simpleInterest
{
    class Program
    {
        static void Main(string[] args)
        {
            float PriciplAmnt;
            int time;
           
            Console.WriteLine("enter priciple amount");
            PriciplAmnt=float.Parse(Console.ReadLine());
            Console.WriteLine("enter time in years");
            time = int.Parse(Console.ReadLine());
            calSI(PriciplAmnt, time);
           

        }

        private static void calSI(float priciplAmnt, int time)
        {
            float Rate_interst;
            if (time==1) 
            {
                Rate_interst = 5.0f;
                Action_si(priciplAmnt, time, Rate_interst);
            
            }
            else if(time>1||time <=4)
            {
                Rate_interst = 8.0f;
                Action_si(priciplAmnt, time, Rate_interst);


            }
            else if (time > 4&& time <= 7)
            {
                Rate_interst = 10.0f;
                Action_si(priciplAmnt, time, Rate_interst);


            }
            else 
            {
                Rate_interst = 12.0f;
                Action_si(priciplAmnt, time, Rate_interst);


            }
        }

        private static void Action_si(float priciplAmnt, int time, float rate_interst)
        {
            double intrst;
            intrst = (priciplAmnt * time * rate_interst) / 100;
            Console.WriteLine("Simple interest is " + intrst);
            double total;
            total = priciplAmnt + intrst;
            Console.WriteLine("Total Amount is " + total);
            Console.ReadLine();



        }
    }
}
