namespace LogonScreen
{
    public partial class Resources_Luna
    {
        public Resources_Luna()
        {
            InitializeComponent();
        }
    }
}