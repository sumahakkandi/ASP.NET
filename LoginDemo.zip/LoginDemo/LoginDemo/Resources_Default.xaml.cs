namespace LogonScreen
{
    public partial class Resources_Default
    {
        public Resources_Default()
        {
            InitializeComponent();
        }
    }
}