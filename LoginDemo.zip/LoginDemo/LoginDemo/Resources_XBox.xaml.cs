namespace LogonScreen
{
    public partial class Resources_XBox
    {
        public Resources_XBox()
        {
            InitializeComponent();
        }
    }
}